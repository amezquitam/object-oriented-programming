package tragaperras;

public enum Fruta {
    FRESA, SANDIA, PLATANO, MELOCOTON, PERA
}
